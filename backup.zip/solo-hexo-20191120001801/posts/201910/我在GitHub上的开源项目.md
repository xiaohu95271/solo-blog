title: 我在 GitHub 上的开源项目
date: '2019-10-31 00:08:00'
updated: '2019-10-31 00:08:00'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/xiaohu95271/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiaohu95271/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiaohu95271/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiaohu95271/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.gyht.top`](http://www.gyht.top "项目主页")</span>

xiaohu95271 的个人博客 - 记录精彩的程序人生



---

### 2. [youmin-hibernate](https://github.com/xiaohu95271/youmin-hibernate) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiaohu95271/youmin-hibernate/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiaohu95271/youmin-hibernate/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/xiaohu95271/youmin-hibernate/network/members "分叉数")</span>





---

### 3. [youmin](https://github.com/xiaohu95271/youmin) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiaohu95271/youmin/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiaohu95271/youmin/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiaohu95271/youmin/network/members "分叉数")</span>





---

### 4. [blog](https://github.com/xiaohu95271/blog) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiaohu95271/blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiaohu95271/blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiaohu95271/blog/network/members "分叉数")</span>





---

### 5. [spring-boot-blog](https://github.com/xiaohu95271/spring-boot-blog) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiaohu95271/spring-boot-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiaohu95271/spring-boot-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiaohu95271/spring-boot-blog/network/members "分叉数")</span>





---

### 6. [springhibernate](https://github.com/xiaohu95271/springhibernate) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/xiaohu95271/springhibernate/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiaohu95271/springhibernate/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiaohu95271/springhibernate/network/members "分叉数")</span>





---

### 7. [springboot-security](https://github.com/xiaohu95271/springboot-security) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/xiaohu95271/springboot-security/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiaohu95271/springboot-security/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiaohu95271/springboot-security/network/members "分叉数")</span>

spring boot集成spring security



---

### 8. [skydrive](https://github.com/xiaohu95271/skydrive) <kbd title="主要编程语言">Dart</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/xiaohu95271/skydrive/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiaohu95271/skydrive/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiaohu95271/skydrive/network/members "分叉数")</span>

手机网盘系统

