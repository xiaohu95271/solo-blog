title: 安装MySQL5.7 解压版
date: '2019-10-31 14:47:15'
updated: '2019-10-31 14:47:15'
tags: [MySQL]
permalink: /articles/2019/10/31/1572504435875.html
---
新建my.ini  
新建一个txt文档，另存为my.ini，放在MySQL目录下
```
[mysql]
# 设置mysql客户端默认字符集
default-character-set=utf8
[mysqld]
#设置3306端口
port = 3306
# 设置mysql的安装目录
basedir=D:\\software\\navicat\\mysql-5.7.28-winx64
# 设置mysql数据库的数据的存放目录
datadir=D:\\software\\navicat\\mysql-5.7.28-winx64\\data
# 允许最大连接数
max_connections=200
# 服务端使用的字符集默认为8比特编码的latin1字符集
character-set-server=utf8
# 创建新表时将使用的默认存储引擎
default-storage-engine=INNODB
explicit_defaults_for_timestamp=true
```
下面安装data  
添加bin目录到path环境变量

环境变量配置：我的电脑 --> 属性 --> 环境变量 --> PATH 加入：D:\Program Files\mysql-5.7.23-winx64\bin

************生成data目录 **************

cmd 用管理员进入

![](https://images2018.cnblogs.com/blog/1230136/201808/1230136-20180804205936982-1791419710.png)

输入格式:

d:

cd D:\Program Files\mysql-5.7.23-winx64\bin

bin目录下执行mysqld install   //安装服务

若出现“缺少xxx.dll，请安装微软运行库

运行 mysqld --initialize-insecure --user=mysql         // 生成data目录 （MySQL 5.7.16往后默认是不提供data目录的）

![](https://images2018.cnblogs.com/blog/1230136/201808/1230136-20180804210549143-1645635872.png)

![](https://images2018.cnblogs.com/blog/1230136/201808/1230136-20180804210657221-846564277.png)

安装服务 

提示:服务已成功安装。

![](https://images2018.cnblogs.com/blog/1230136/201808/1230136-20180804211317965-1007410399.png)

 启动服务

 ![](https://images2018.cnblogs.com/blog/1230136/201808/1230136-20180804211420782-71372212.png)

mysqld --remove   //删除服务

mysqld --install     //安装服务

net start mysql     //启动服务

net stop mysql    //关闭MySQL服务的命令

  

**show databases   //查看数据库**

**exit           //退出**

 ![](https://images2018.cnblogs.com/blog/1230136/201808/1230136-20180804212432007-480092342.png)

 

如果没有密码要设置密码如下:

mysql默认的root用户是没有设置密码的，我们可以修改root用户密码，方法如下：

1、直接在cmd命令行，不需要进入mysql

mysqladmin -u root password 新密码
